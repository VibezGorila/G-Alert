# G-Alert
Basic alert when you are bellow limit of water and food.

Fully Optimized 

My discord with great scripts : https://discord.gg/NwkgbTa3SH

If you want to change something go into client.

Requirements : esx_status , esx-framework
